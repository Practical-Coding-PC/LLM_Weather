## weather.db 쿼리문 작성 법

1. cd LLM_Weather
2. sqlite3 weather.db

** 명령어
.tables