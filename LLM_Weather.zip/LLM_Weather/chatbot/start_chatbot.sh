#!/bin/bash

echo "🌤️📹 날씨 & CCTV 챗봇 서버를 시작합니다..."

# 가상환경 활성화 (필요한 경우)
# source venv/bin/activate

# 필요한 패키지 설치 확인
echo "의존성 패키지 확인 중..."
pip install -q fastapi uvicorn python-dotenv google-generativeai pandas requests pytz

# 환경 변수 확인
echo "환경 변수 확인 중..."
if [ -f "../.env" ]; then
    echo "✅ .env 파일이 존재합니다"
    
    # Gemini API 키 확인
    if grep -q "GEMINI_API_KEY=" "../.env"; then
        echo "✅ Gemini API 키가 설정되어 있습니다"
    else
        echo "⚠️ Gemini API 키가 설정되지 않았습니다"
    fi
    
    # 기상청 API 키 확인
    if grep -q "KMA_SERVICE_KEY=" "../.env"; then
        echo "✅ 기상청 API 키가 설정되어 있습니다"
    else
        echo "⚠️ 기상청 API 키가 설정되지 않았습니다"
    fi
    
    # CCTV API 키 확인
    if grep -q "REACT_APP_CCTV_API_KEY=" "../.env"; then
        echo "✅ CCTV API 키가 설정되어 있습니다"
    else
        echo "⚠️ CCTV API 키가 설정되지 않았습니다"
    fi
else
    echo "❌ .env 파일이 존재하지 않습니다!"
    echo "상위 디렉토리에 .env 파일을 생성하고 다음 키들을 설정해주세요:"
    echo "GEMINI_API_KEY=your_key_here"
    echo "KMA_SERVICE_KEY=your_key_here"
    echo "REACT_APP_CCTV_API_KEY=your_key_here"
fi

echo ""
echo "🚀 서버를 시작합니다..."
echo "💡 브라우저에서 http://localhost:8000 으로 접속하세요"
echo "⏹️ 서버를 중지하려면 Ctrl+C를 누르세요"
echo ""

# 서버 시작
python chatbot_app.py
