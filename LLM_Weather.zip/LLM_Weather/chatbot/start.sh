#!/usr/bin/env bash
# 가상환경 활성화 (필요한 경우)
# source venv/bin/activate


# 필요한 패키지 설치
pip3 install -r requirements.txt
python3.11 chatbot_app.py
