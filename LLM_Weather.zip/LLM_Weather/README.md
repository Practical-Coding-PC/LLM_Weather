app.py : Apply flask server
config.py : Set environment values
db.py : Set MySQL connection
models.py : DB model
requirements.txt : List of necessary packages
routes.py : Define API routes